<?php
$page_title = 'View Your Shopping Cart';
include ('includes/header.html');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	
	foreach ($_POST['qty'] as $k => $v) {

		
		$pid = (int) $k;
		$qty = (int) $v;
		
		if ( $qty == 0 ) { 
			unset ($_SESSION['cart'][$pid]);
		} elseif ( $qty > 0 ) { 
			$_SESSION['cart'][$pid]['quantity'] = $qty;
		}
		
	} 
	
} 


if (!empty($_SESSION['cart'])) {


	require (CONNECT_OOP); 
	$q = "SELECT print_id, CONCAT_WS(' ', first_name, middle_name, last_name) AS artist, print_name, image_name FROM sc_artists, sc_prints WHERE sc_artists.artist_id = sc_prints.artist_id AND sc_prints.print_id IN (";
	foreach ($_SESSION['cart'] as $pid => $value) {
		$q .= $pid . ',';
	}
	$q = substr($q, 0, -1) . ') ORDER BY sc_artists.last_name ASC';
	$r = mysqli_query ($link, $q);
	
	
	echo '<form action="" method="post">
	<table border="0" width="90%" cellspacing="3" cellpadding="3" align="center">
	<tr>
		<td align="left" width="20%"><b>Artist</b></td>
		<td align="left" width="20%"><b>Print Name</b></td>
		<td align="left" width="20%"><b>Image</b></td>
		<td align="right" width="15%"><b>Price</b></td>
		<td align="center" width="15%"><b>Qty</b></td>
		<td align="right" width="10%"><b>Total Price</b></td>
	</tr>
	';

	
	$total = 0;
	while ($row = mysqli_fetch_array ($r, MYSQLI_ASSOC)) {
	
		$subtotal = $_SESSION['cart'][$row['print_id']]['quantity'] * $_SESSION['cart'][$row['print_id']]['price'];
		$total += $subtotal;
		
		
		echo "\t<tr>
		<td align=\"left\">{$row['artist']}</td>
		<td align=\"left\">{$row['print_name']}</td>
		<td align=\"left\">{$row['image_name']}</td>
		<td align=\"right\">\${$_SESSION['cart'][$row['print_id']]['price']}</td>
		<td align=\"center\"><input type=\"text\" size=\"3\" name=\"qty[{$row['print_id']}]\" value=\"{$_SESSION['cart'][$row['print_id']]['quantity']}\" /></td>
		<td align=\"right\">$" . number_format ($subtotal, 2) . "</td>
		</tr>\n";
	
	} 

	mysqli_close($link);

	
	echo '<tr>
		<td colspan="5" align="right"><b>Total:</b></td>
		<td align="right">$' . number_format ($total, 2) . '</td>
	</tr>
	</table>
	<div align="center"><input type="submit" name="submit" value="Update My Cart" /></div>
	</form><p align="center">Enter a quantity of 0 to remove an item.
	<br /><br /><a href="index.php?chapter=19&script=19.11">Checkout</a></p>';

} else {
	echo '<p>Your cart is currently empty.</p>';
}

include ('includes/footer.html');
?>