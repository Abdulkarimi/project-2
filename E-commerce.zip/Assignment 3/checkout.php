<?php 
$page_title = 'Order Confirmation';
include ('includes/header.html');


$cid = 1; 


$total = 178.93; 

require (CONNECT_OOP); 


mysqli_autocommit($link, FALSE);


$q = "INSERT INTO sc_orders (customer_id, total) VALUES ($cid, $total)";
$r = mysqli_query($link, $q);
if (mysqli_affected_rows($link) == 1) {

	
	$oid = mysqli_insert_id($link);
	
	
	$q = "INSERT INTO sc_order_contents (order_id, print_id, quantity, price) VALUES (?, ?, ?, ?)";
	$stmt = mysqli_prepare($link, $q);
	mysqli_stmt_bind_param($stmt, 'iiid', $oid, $pid, $qty, $price);
	
	
	$affected = 0;
	foreach ($_SESSION['cart'] as $pid => $item) {
		$qty = $item['quantity'];
		$price = $item['price'];
		mysqli_stmt_execute($stmt);
		$affected += mysqli_stmt_affected_rows($stmt);
	}

	
	mysqli_stmt_close($stmt);

	
	if ($affected == count($_SESSION['cart'])) { // Whohoo!
	
		
		mysqli_commit($link);
		
		
		unset($_SESSION['cart']);
		
		
		echo '<p>Thank you for your order. You will be notified when the items ship.</p>';
		
		
	
	} else {
	
		mysqli_rollback($link);
		
		echo '<p>Your order could not be processed due to a system error. You will be contacted in order to have the problem fixed. We apologize for the inconvenience.</p>';
	
		
	}

} else { 

	mysqli_rollback($link);

	echo '<p>Your order could not be processed due to a system error. You will be contacted in order to have the problem fixed. We apologize for the inconvenience.</p>';
	
	
	
}

mysqli_close($link);

include ('includes/footer.html');
?>
