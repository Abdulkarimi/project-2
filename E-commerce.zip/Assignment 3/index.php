<?php 
$page_title = 'Make an Impression!';
include ('includes/header.html');
?>

<p>Welcome to our site....please use the links above...blah, blah, blah.</p>
<p>Welcome to our site....please use the links above...blah, blah, blah.</p>

<?php include ('includes/footer.html'); ?>